Dear TA：

This homework I search many information about how to write my own allocator before and during my writing time. I do understand it is difficult for me, so I have looked some homework in the github. I truely understand the principle and basically know how to write it.

You can run the tester.cpp in dev-c++ or anyone else. And the test result will be shown on the terminal. The important things are listed on the report. Thanks for your help during this semester! 