#ifndef _MYALLOCATOR_HPP
#define _MYALLOCATOR_HPP
#include <iostream>
#include <memory>
#include <cstddef>
#include <cstdlib>
#include <new>

class FirstAlloc // 直接调用系统函数分配
{
public:
    static void *allocate(std::size_t n)
    {
        // std::cout << "FirstAlloc类的allocate函数\n";
        void *res = std::malloc(n); // 内存过大的情况，直接用malloc分配
        if (res == nullptr)
            throw std::bad_alloc(); // 分配失败时，抛出异常
        return res;
    }

    static void deallocate(void *p, std::size_t)
    {
        // std::cout << "FirstAlloc类的deallocate函数\n";
        std::free(p);
    }
};

enum enum1
{
    MAX_BYTES = 65536,                   // memory block中能存储的最大bytes
    BOUND = 64,                          // 每个unit中存储的bytes数目
    COUNT_FREE_LISTS = MAX_BYTES / BOUND // 每个block中的unit，共有1024个
};

union obj // 联合体类型存储节省空间，表示实际块或者下一个空闲块
{
    union obj *free_list_link;
    char client_data[1];
};

class SecondAlloc // 用内存池二级分配
{
private:
    static obj *volatile free_list[COUNT_FREE_LISTS]; // 记录当前的free list

    static char *mempoolstart;    // 记录内存池起始位置的指针
    static char *mempoolend;      // 记录内存池截止位置的指针
    static std::size_t heap_size; // 用于动态内存分配的堆空间

    static std::size_t free_list_index(std::size_t bytes) // 计算free list的下标
    {
        return ((bytes) + BOUND - 1) / BOUND - 1; // bytes是需要的位
    }

    static std::size_t ceil_up(std::size_t bytes)
    {
        return (((bytes) + BOUND - 1) & ~(BOUND - 1)); // 将bytes上调至BOUND的倍数
    }

    static char *big_alloc(std::size_t size, int &cnt_obj) // 运用内存池进行内存分配
    {
        // std::cout << "refill and big_alloc\n";
        char *res;
        std::size_t total_bytes = size * cnt_obj;           // 需要的bytes
        std::size_t left_bytes = mempoolend - mempoolstart; // 内存池的剩余内存

        if (left_bytes >= total_bytes) // 内存池中剩余内存足够
        {
            res = mempoolstart; // 分配空间
            mempoolstart += total_bytes;
            return res;
        }
        else if (left_bytes >= size) // 内存池中内存不够
        {
            cnt_obj = left_bytes / size;
            total_bytes = size * cnt_obj;
            res = mempoolstart;
            mempoolstart += total_bytes;
            return res;
        }
        else
        {
            std::size_t get_bytes = 2 * total_bytes + ceil_up(heap_size >> 4); // get_bytes是开辟的内存byte数
            if (get_bytes > 0 && mempoolstart != nullptr)                      // 如果还有空间
            {
                obj *volatile *my_free_list = free_list + free_list_index(left_bytes); // 调整free list

                ((obj *)mempoolstart)->free_list_link = *my_free_list;
                *my_free_list = (obj *)mempoolstart;
            }

            mempoolstart = (char *)malloc(get_bytes); // 开辟get_bytes大小的内存作为start
            heap_size += get_bytes;
            mempoolend = mempoolstart + get_bytes; // 记录内存池开始和结束地址

            return big_alloc(size, cnt_obj); // 开辟结束，调用函数进行分块（会进入前两个分支）
        }
    }

    static void *refill(std::size_t n) // 返回占用n个空间的对象
    {
        int cnt_obj = 20; // 预先决定分配20size
        char *big = big_alloc(n, cnt_obj);
        obj *volatile *my_free_list;
        obj *res;
        obj *current_obj;
        obj *next_obj;

        if (cnt_obj == 1) // 只有1个block
            return big;

        my_free_list = free_list + free_list_index(n); // 调整free list的下标
        res = (obj *)big;                              // 返回的块
        next_obj = (obj *)(big + n);
        *my_free_list = (obj *)(big + n);

        for (int i = 1;; i++) // 运用链表链接保存的块
        {
            current_obj = next_obj;
            next_obj = (obj *)((char *)next_obj + n);
            if (cnt_obj == i + 1) // 最后一步
            {
                current_obj->free_list_link = nullptr;
                break;
            }
            else // 不是最后一步
            {
                current_obj->free_list_link = next_obj; // 链表的指针后移
            }
        }
        return res;
    }

public:
    static void *allocate(std::size_t n)
    {
        // std::cout << "SecondAlloc类中的allocate函数\n";
        obj *volatile *cur_free_list;
        obj *res;

        if (n > (std::size_t)MAX_BYTES) // 所需的内存大于最大bytes 用第一级分配
        {
            return FirstAlloc::allocate(n);
        }

        cur_free_list = free_list + free_list_index(n);
        res = *cur_free_list; // 寻找适合的free list

        if (res == nullptr) // 没有free list时，调用refill函数
        {
            void *r = refill(ceil_up(n));
            return r;
        }

        *cur_free_list = res->free_list_link; // 更新当前的free list
        return res;
    }

    static void deallocate(void *p, std::size_t n) // 返还分配的空间
    {
        // std::cout << "SecondAlloc类中的deallocate函数\n";
        obj *q = (obj *)p;
        obj *volatile *cur_free_list;

        if (n > (std::size_t)MAX_BYTES) // 内存过大，用第一级返还函数
        {
            FirstAlloc::deallocate(p, n);
            return;
        }

        cur_free_list = free_list + free_list_index(n); // 寻找合适的free list

        q->free_list_link = *cur_free_list;
        *cur_free_list = q;
    }
};
// 初始化第二级分配器的变量
char *SecondAlloc::mempoolstart = nullptr;
char *SecondAlloc::mempoolend = nullptr;
std::size_t SecondAlloc::heap_size = 0;
obj *volatile SecondAlloc::free_list[COUNT_FREE_LISTS] = {nullptr};

template <class T>
class MyAllocator // 分配器类的接口
{
public:
    typedef void _Not_user_specialized; // 需要操作的变量名typedef
    typedef T value_type;
    typedef value_type *pointer;
    typedef const value_type *const_pointer;
    typedef value_type &reference;
    typedef const value_type &const_reference;
    typedef std::size_t size_type;
    typedef ptrdiff_t difference_type;
    typedef std::true_type propagate_on_container_move_assignment;
    typedef std::true_type is_always_equal;

    MyAllocator() = default; // 空构造

    template <class U>
    MyAllocator(const MyAllocator<U> &o) noexcept(true) // 拷贝构造
    {
    }
    pointer address(reference _Val) const noexcept(true) // 不抛出异常，节约时间
    {
        return &_Val;
    }
    const_pointer address(const_reference _Val) const noexcept(true)
    {
        return &_Val;
    }

    pointer allocate(size_type _Count) // 分配函数，先进入第二级分配
    {
        // std::cout << "MyAllocator中的allocate函数\n";
        if (_Count > size_type(-1) / sizeof(value_type))
            throw std::bad_alloc();
        if (auto p = static_cast<pointer>(SecondAlloc::allocate(_Count * sizeof(value_type))))
        {
            return p;
        }
        throw std::bad_alloc();
    }

    void deallocate(pointer _Ptr, size_type _Count) // 返还空间，同样先进入第二级
    {
        // std::cout << "MyAllocator中的deallocate函数\n";
        SecondAlloc::deallocate(_Ptr, _Count);
    }

    template <class _Uty>
    void destroy(_Uty *ptr)
    {
        ptr->~_Uty();
    }

    template <class _Objty, class... _Types>
    void construct(_Objty *_Ptr, _Types &&..._Args)
    {
        ::new (const_cast<void *>(static_cast<const volatile void *>(_Ptr)))
            _Objty(std::forward<_Types>(_Args)...);
    }
};

template <class T1, class T2> // 重载等号和不等号 直接返回true和false
bool operator==(const MyAllocator<T1> &lhs, const MyAllocator<T2> &rhs)
{
    return true;
}

template <class T1, class T2>
bool operator!=(const MyAllocator<T1> &lhs, const MyAllocator<T2> &rhs)
{
    return false;
}

#endif